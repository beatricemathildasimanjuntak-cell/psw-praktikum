/*
NAMA        : BEATRICE SIMANJUNTAK
NIM         : 41426014
PRODI       : TRPL
*/

1. STARTER KATALOG
    Kegiatan, Index, dan Kontak html terhubung dengan baik ke css dengan susunan yang rapi. dan pada kegiatan starter valid dengan tiga card.
2. NAVIGASI FLEKSIBEL
    Saat jadwal di kecilkan memakai devtools itemnya wrap ke bawah ketika ruang nya tidak cukup
3. CARD FLEKSIBEL
    Ukuran card nya menyesuaikan ukuran dan jumlah baris menyesuaikan ruang
4. KONTEN PANJANG DAN PENGUKURAN
    Saat teks dibuat panjang teks mengisi ruang kosong dan tidak ada informasi penting yang terpotong,
    saat saya uji zoom 200 setiap ruang kosong diisi, dan ketika tidak ada overflow saya menyertakan buktinya di screenshot hasil
5. LATIHAN MANDIRI DAN MATRIKS UJI
Kasus               | Harapan
360px               | Card wrap tanpa overflow 
Empat item          | Semua card tampil
Judul panjang       | Teks tidak keluar kotak
Tab Link            | tetap dapat dicapai

**Format laporan yang diisi mahasiswa**
> Input/kondisi       Tindakan        Hasil aktual            Status/bukti
> 
> Kasus normal        Diisi           Diisi setelah uji       Diisi
> 
> Kasus batas         Diisi           Diisi setelah uji       Diisi
> 
> Kasus gagal         Diisi           Diisi setelah uji       Diisi


**## > HASIL AKHIR BERBEDA SAMA BUKTI KARNA DIUBAH**

*gambar tertera adalah milik saya pribadi*
