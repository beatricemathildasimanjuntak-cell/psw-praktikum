/*
NAMA        : BEATRICE SIMANJUNTAK
NIM         : 41426014
PRODI       : TRPL
*/

3. MENGUBAH CONTAINER
    card tersusun dalam dua kolom. jika ada empat kolom maka dua kolom kesamping dan dua kebawah
4. GRID ADAPTIF
    mengubah lebar pada web menjadi sekitar 320px, 768px, dan 1200px. jumlah kolom akan menyesuaikan ukuran ruang
5. CARD INTERNAL DAN GAP
    setiap card menampilkan judul, deskripsi dengan consisten. dan jarak antar isi terlihat konsisten.
6. REVIEW LAYOUT
    urutan card mengikuti susunan elemen html. fokus keyboard berpindah.
7. LATIHAN MANDIRI DAN MATRIKS UJI

Kasus               |Harapan

320px               |Tidak overflow
Satu card           |Card tetap terbaca
Lima card           |Auto-placement benar
Urutan Tab          |Sama dengan alur DOM

Format laporan yang diisi mahasiswa

Input/kondisi      |Tindakan                            |Hasil aktual                         |Status/bukti
Kasus normal       |Membuka web pada layar normal       |semua card sesuai dengan layout      |Berhasil
Kasus batas        |menguji layar 320 px                |card masih berada di container       |Berhasil
Kasus gagal        |memasukkan teks sangat panjang      |teks keluar dari card                |Gagal
