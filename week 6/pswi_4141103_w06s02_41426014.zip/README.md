/*
Nama    : Beatrice Simanjuntak
NIM     : 41426014
*/
> 3. STARTER MOBILE
    pada ukuran 320 px yang sama seperti layar hp kartu kegiatan tersusun 1 baris kebawah dan semua konten dan link tersedia
> 4. BREAKPOINT KONTEN
*  Ukuran 767 px sama dengan 47,9375 rem pada viewport ini	Kartu kegiatan masih tersusun satu kolom
* Ukuran 768 px sama dengan 48 rem Kartu kegiatan berubah menjadi dua kolom	Media query mulai aktif karna kondisi min-width: 48 rem sudah memenuhi syarat
* Ukuran 769 px sama dengan 48,0625 rem Kartu kegiatan tetap dua kolom	Tata letak dua kolom masih dipertahankan

> 5.  NAVIGASI DAN FORM
    Pada viewport 320 px teks tetap terbaca dan tidak keluar dari wadah. Tombol dan kolom input tetap berada di dalam wadah dan tombol Tab pada keyboard berfungsi untuk bisa berpindah fokus pada tautan, input, dan tombol.

> 6. MATRIKS VIEWPORT
* Pada uji viewport 320px, 768px, 1200px kartu kegiatan menyesuaikan ukuran dari layar nya, teksnya tetap dapat dibaca dan tidak terjadi scroll horizontal yang tidak diperlukan
* pada Uji zoom 200% Setelah diperbesar, ukuran teks dan elemen pada halaman menjadi lebih besar
* Temukan satu overflow yang disengaja dengan width 900px lalu perbaiki
    >>>menambahkan width: 900px pada .card h3 untuk melihat pengaruh lebar elemen terhadap tampilan halaman. Pada viewport 320 px, kartu menjadi terlalu lebar sampai keluar dari wadah layarnya. Setelah itu, width: 900px dihapus dan halaman kemudian diuji kembali untuk melihat apakah kartu sudah menyesuaikan lebar wadah dan tidak menyebabkan scroll horizontal. Hasil nya ada di screenshot

7. LATIHAN MANDIRI DAN MATRIKS UJI
* 320px konten lengkap tanpa ada yang terpotong
* Sekitar breakpoint : 768 px kartu kegiatan jadi dua baris kesamping
* Zoom 200% : Teksnya tidak terpotong
* Keyboard : Fokus terlihat (tampilkan salam)
