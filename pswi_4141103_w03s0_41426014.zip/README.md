HASIL UJI 
1. Email kosong : Tidak dapat dikirim/ditolak karna ada required
2. Email abc    : Ditolak karna type nya tidak email
3. Keyboard     : Semua kontrol dapat dicapai
4. abc123 pada NIM  : Ditolak karna ada huruf
5. 12345            : Ditolak karna wajib 6 angka
6. 001234           : Diterima karna memenuhi syarat
7. Mengapa server tetap perlu memvalidasi?
//Server tetap perlu memvalidasi karna untuk memastikan data yang diterima sesuai aturan dan aman.// 

Hasil Pengamatan:
Form dapat dijalankan dan setiap kontrol dapat berfungsi setiap labelnya terhubung dengan input.
Setiap kontrol dapat dijangkau melalui keyboard.
Setelah pengujian form berjalan dengan baik.

Cara Menjalankan:
1. Buka VSCODE
2. Buka File
3. Buka index.html
4. Klik Open live Server
5. Halaman akan terbuka di web
