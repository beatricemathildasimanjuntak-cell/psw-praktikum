/*
Nama    : Beatrice Mathilda Simanjuntak
NIM     : 41426014
Prodi   : d4 Trpl
*/

*/Penggunaan AI
Saya menggunakan AI untuk memperbaiki dan menambah style.css agar kotak di form jadi rapi
*/

/*PENJELASAN HASIL UJI

Kasus normal:
Semua data diisi dengan benar. Form berhasil dijalankan
dan tidak terdapat masalah pada tampilan.

Kasus batas:
Nama dibuat sangat panjang dan jumlah tiket diisi 5.
Hasil uji menunjukkan ukuran input tetap
rapi dan tidak keluar dari area kotak.

Kasus gagal:
email diisi dengan format
yang salah. Form menolak pengiriman sampai data diperbaiki.
*/

*/PENJELASAN KASUS
CSS path salah >>> 404 dan gaya tidak muncul
content-box >>> Border-box 276px
border-box >>> Border-box 240px
*/

/*HASIL VALIDATOR
Tidak ada error
*/

